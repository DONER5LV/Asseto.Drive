#!/usr/bin/env python3
"""Preflight: lay every sheet over the others and list what is unfilled,
unverified, or does not resolve. Build only when this is clean."""
import json, pathlib, sys

ROOT = pathlib.Path(__file__).parent / "sheets"
NAMES = ["games", "messages", "car_classes", "systems", "components", "listing"]
rows = {n: json.loads((ROOT / f"{n}.json").read_text(encoding="utf-8"))["rows"] for n in NAMES}

unfilled, unverified, broken = [], [], []

def rid(row, i):
    return row.get("id") or row.get("slug") or f"row{i}"

def walk(sheet, rowid, path, val):
    if val is None:
        unfilled.append(f"{sheet}.{rowid}.{path}")
    elif isinstance(val, dict):
        for k, v in val.items():
            walk(sheet, rowid, f"{path}.{k}", v)
    elif isinstance(val, list):
        for i, v in enumerate(val):
            walk(sheet, rowid, f"{path}[{i}]", v)

for n in NAMES:
    for i, row in enumerate(rows[n]):
        r = rid(row, i)
        for k, v in row.items():
            walk(n, r, k, v)
        if row.get("status") != "verified":
            unverified.append((f"{n}.{r}", len(row.get("to_verify", []))))

msg = {m["id"]: m for m in rows["messages"]}
sids = {s["id"] for s in rows["systems"]}
slugs = {g["slug"] for g in rows["games"]}
side_game = {"ac": "assetto-corsa", "beamng": "beamng-drive", "melty": "melty"}
producers, consumers, implemented = {}, {}, {}

for s in rows["systems"]:
    sid = s["id"]
    for d in s["depends_on"]:
        if d not in sids:
            broken.append(f"systems.{sid}.depends_on -> {d} does not exist")
    for m in s["consumes"] + s["produces"] + s["carries"]:
        if m not in msg:
            broken.append(f"systems.{sid} -> message {m} does not exist")
    for sh in s["reads_sheets"]:
        if sh not in NAMES:
            broken.append(f"systems.{sid}.reads_sheets -> sheet {sh} does not exist")
    for m in s["produces"]:
        producers.setdefault(m, []).append(sid)
        if m in msg and s["side"] in ("ac", "beamng") and msg[m]["from"] != s["side"]:
            broken.append(f"systems.{sid} (side {s['side']}) produces {m} but {m} is sent from {msg[m]['from']}")
    for m in s["consumes"]:
        consumers.setdefault(m, []).append(sid)
        if m in msg and s["side"] in ("ac", "beamng") and msg[m]["to"] != s["side"]:
            broken.append(f"systems.{sid} (side {s['side']}) consumes {m} but {m} is sent to {msg[m]['to']}")

for m in msg:
    if m not in producers:
        broken.append(f"messages.{m} has no producing system")
    if m not in consumers:
        broken.append(f"messages.{m} has no consuming system")

for c in rows["components"]:
    if c["target_game"] not in slugs and c["target_game"] != "melty":
        broken.append(f"components.{c['id']}.target_game -> {c['target_game']} is not in games")
    for sid in c["implements"]:
        if sid not in sids:
            broken.append(f"components.{c['id']}.implements -> {sid} does not exist")
        implemented.setdefault(sid, []).append(c["id"])
        sys_row = next((s for s in rows["systems"] if s["id"] == sid), None)
        if sys_row and sys_row["side"] in side_game and side_game[sys_row["side"]] != c["target_game"]:
            broken.append(f"{sid} runs on {sys_row['side']} but {c['id']} targets {c['target_game']}")

for sid in sids:
    if sid not in implemented:
        broken.append(f"systems.{sid} is not implemented by any component")

for c in rows["car_classes"]:
    pass
if sum(1 for c in rows["car_classes"] if c["is_fallback"]) != 1:
    broken.append("car_classes must have exactly one is_fallback row")

print(f"UNFILLED CELLS ({len(unfilled)}):")
for u in unfilled: print("  -", u)
print(f"\nBROKEN REFERENCES ({len(broken)}):")
for b in broken: print("  -", b)
print(f"\nUNVERIFIED ROWS ({len(unverified)}), open to-verify items per row:")
for name, k in unverified: print(f"  - {name}: {k}")
total = sum(k for _, k in unverified)
print(f"\nTotal open to-verify items: {total}")
clean = not unfilled and not broken and not unverified
print("RESULT:", "CLEAN, ok to build" if clean else "NOT CLEAN, do not build yet")
sys.exit(0 if clean else 1)
